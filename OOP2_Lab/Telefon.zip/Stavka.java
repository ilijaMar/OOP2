package Imenik;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;

public class Stavka extends Panel {
	
	Label naslov=new Label();
	Label tekst=new Label();
	
	public Stavka(String naslov,String tekst)
	{
		this.setLayout(new GridLayout(2,1));
		this.add(this.naslov, 0);
		this.add(this.tekst, 1);
	
		this.naslov.setText(naslov);
		this.tekst.setText(tekst);
		this.naslov.setFont(new Font("Ariel", Font.BOLD, 15));
	}
	
	public void setNaslov(Label naslov) {
		this.naslov = naslov;
	}

}
