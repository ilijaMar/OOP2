package Imenik;

import java.awt.Panel;
import java.util.ArrayList;

public class ListaStavki extends Panel {
	
	ArrayList<Stavka> stavke=new ArrayList<>();
	
	
	
	
	

}
