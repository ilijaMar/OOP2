package Imenik;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Dialog.ModalityType;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;



public class Telefon extends Panel {
	
	
	Frame ownerFrame;
	private class PotvrdiGasenje extends Dialog
	{
		private Button okButton=new Button("Ok");
		private Button cancelButton=new Button("Cancel");
		
		public void paint(Graphics g)
		{
			g.drawString("Poziv od: "+brojTelefona, 20, 70);
			super.paint(g);
		}
		public PotvrdiGasenje(Frame owner) {
			super(owner);
			setTitle("Potvrditi");
			setBounds(owner.getX()+owner.getWidth()/2,owner.getY()+owner.getHeight()/2,200,150);
			setResizable(false);
			setModalityType(ModalityType.APPLICATION_MODAL);//ne moze nista drugo da se klikne izvan dijaloga
			
			Panel dugmiciPanel=new Panel();
			
			okButton.addActionListener((ae)->{
				//Telefon.this.dispose();
			});
			cancelButton.addActionListener((ae)->{
				//PotvrdiGasenje.this.dispose();
			});
			dugmiciPanel.add(okButton);
			dugmiciPanel.add(cancelButton);
			
			add(dugmiciPanel,BorderLayout.SOUTH);
			addWindowListener(new WindowAdapter() {
				
				@Override
				public void windowClosing(WindowEvent e) {
					dispose();
				}
			});
			setVisible(true);
			
		}
		
	}
	
	
	private BrojTelefona brojTelefona;
	private Color boja;
	private Button dodajKonta=new Button("Dodaj kontakt");
	private Button stanjeTelefona=new Button("Iskljuci telefon");
	
	private Imenik imenik=new Imenik();
	private Tastatura tastatura=new Tastatura();
	private Panel dodavaniKontakt=new Panel(new GridLayout(2,1));
	
	
	private int brojKlika=0;
	
	

	
	public void dodajKomponente()
	{
		Panel brojTelefonaPanel=new Panel(new FlowLayout(FlowLayout.CENTER));
		Label brojTelefonaLabel=new Label("+381607030350");
		brojTelefonaPanel.setSize(new Dimension(this.getWidth(),10));
		brojTelefonaLabel.setText(this.getBrojTelefona().toString());
		brojTelefonaPanel.setBackground(this.getBoja());
		brojTelefonaLabel.setBackground(this.getBoja());
		brojTelefonaLabel.setFont(new Font("Arial", Font.BOLD, 20));
		
		brojTelefonaPanel.add(brojTelefonaLabel);
		
		
		
		this.setLayout(new BorderLayout());
		Panel dvaDugmeta=new Panel(new GridLayout(0,2));
		stanjeTelefona.setBackground(Color.GRAY);
		dvaDugmeta.add(dodajKonta);
		dvaDugmeta.add(stanjeTelefona);
		
		Panel donjiPanel=new Panel(new GridLayout(2,1));
		donjiPanel.add(dvaDugmeta,0);
		donjiPanel.add(brojTelefonaPanel,1);
		this.add(donjiPanel,BorderLayout.SOUTH);
		
		Panel gornjiPanel=new Panel(new BorderLayout());
		
		
		tastatura.getNatpis().setFont(new Font("Ariel", ALLBITS, 20));
		
		imenik.setPreferredSize(new Dimension(this.getWidth(),240));
		
		
		dodavaniKontakt.add(tastatura.getNatpis(),0);
		dodavaniKontakt.add(tastatura.getNatpisi(),1);
		
		
		dodajKonta.addActionListener((ae)->{
			
			
			if(brojKlika==0)
			{
				tastatura.getJedanButton().setLabel("");
				tastatura.getDvaButton().setLabel("ABC");
				tastatura.getTriButton().setLabel("DEF");
				tastatura.getCetiriButton().setLabel("GHI");
				tastatura.getPetButton().setLabel("JKL");
				tastatura.getSestButton().setLabel("MNO");
				tastatura.getSedamButton().setLabel("PQRS");
				tastatura.getOsamButton().setLabel("TUV");
				tastatura.getDevetButton().setLabel("WXYZ");
				tastatura.getNulaButton().setLabel("_");
				tastatura.getZvezdicaButton().setLabel("");
				tastatura.getPlusButton().setLabel("");
				
				
				tastatura.setFlag(1);
				
				
				brojKlika++;
			}else if(brojKlika==1)
			{
				tastatura.getJedanButton().setLabel("1");
				tastatura.getDvaButton().setLabel("2");
				tastatura.getTriButton().setLabel("3");
				tastatura.getCetiriButton().setLabel("4");
				tastatura.getPetButton().setLabel("5");
				tastatura.getSestButton().setLabel("6");
				tastatura.getSedamButton().setLabel("7");
				tastatura.getOsamButton().setLabel("8");
				tastatura.getDevetButton().setLabel("9");
				tastatura.getNulaButton().setLabel("0");
				tastatura.getZvezdicaButton().setLabel("*");
				tastatura.getPlusButton().setLabel("+");
				
				BrojTelefona noviBroj=new BrojTelefona(tastatura.getNatpis().getText());
				brojTelefona=noviBroj;
				//Kontakt noviKontakt=new Kontakt(tastatura.getNatpisi().getText(),noviBroj);
				//Stavka stavkaZaImenik=new Stavka(tastatura.getNatpisi().getText(),tastatura.getNatpis().getText());

				imenik.dodajKontakt(new Stavka(tastatura.getNatpisi().getText(),tastatura.getNatpis().getText()));
				imenik.ispisImenika();
				
				
				
				
				
			
				tastatura.getNatpis().setText("");
				tastatura.getNatpisi().setText("");
				tastatura.setFlag(0);
				brojKlika--;
			}
		});
		
		stanjeTelefona.addActionListener((ae)->{
			
			new PotvrdiGasenje(ownerFrame);
			if(brojKlika==0)
			{
				stanjeTelefona.setBackground(Color.RED);
				stanjeTelefona.setLabel("Ukljuci telefon");
				brojKlika++;
			}
			else if(brojKlika==1)
			{
				stanjeTelefona.setBackground(Color.GRAY);
				stanjeTelefona.setLabel("Iskljuci telefon");
				brojKlika--;	
			}
		});
		
		Panel tastaturaPanel=new Panel(new BorderLayout());
		tastaturaPanel.add(tastatura,BorderLayout.CENTER);
		tastaturaPanel.add(dodavaniKontakt,BorderLayout.NORTH);
		this.setBackground(boja);
		gornjiPanel.add(tastaturaPanel,BorderLayout.NORTH);
		gornjiPanel.add(imenik,BorderLayout.SOUTH);
		
		this.add(gornjiPanel,BorderLayout.NORTH);
		
		gornjiPanel.revalidate();
		donjiPanel.revalidate();
		
	}
	public Telefon(BrojTelefona brojTelefona, Color boja,Frame owner) 
	{
		
		
		
		this.ownerFrame=owner;
		
		this.brojTelefona = brojTelefona;
		this.boja = boja;
		dodajKomponente();
	
	}
	

	public BrojTelefona getBrojTelefona() {
		return brojTelefona;
	}
	
	public Color getBoja() {
		return boja;
	}

	/*
	public static void main(String[] args) {
		
		new Telefon(new BrojTelefona("+381607030350"), Color.GREEN);
	}
	*/

}
