package Imenik;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Panel;
import java.awt.Dialog.ModalityType;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class App extends Frame {

	private Telefon telefon1;
	private Telefon telefon2;
	Panel brojTelefonaPanel1=new Panel(new FlowLayout(FlowLayout.CENTER));
	
	Label brojTelefonaLabel=new Label();
	
	Color bojaTelefona;
	public void dodajKomponente()
	{
		MenuBar meni=new MenuBar();
		Menu bgColorMenu=new Menu("Bg color");
		MenuItem bgWhItem=new MenuItem("white");
		MenuItem bgGray=new MenuItem("gray");
		
		bgColorMenu.add(bgWhItem);
		bgColorMenu.add(bgGray); 
		
		bgWhItem.addActionListener((ae)->{
			
			bojaTelefona=Color.WHITE;
		});
		bgGray.addActionListener((ae)->{
			
			bojaTelefona=Color.GRAY;
		});
		meni.add(bgColorMenu);
		this.setMenuBar(meni);
		
		this.setLayout(new GridLayout(0,2));
		telefon1=new Telefon(new BrojTelefona("+381607030350"), Color.GREEN,this);
		telefon2=new Telefon(new BrojTelefona("+381638097132"), Color.YELLOW,this);
		
		brojTelefonaPanel1.setSize(new Dimension(telefon1.getWidth(),10));
		brojTelefonaLabel.setText(telefon1.getBrojTelefona().toString());
		brojTelefonaPanel1.setBackground(telefon1.getBoja());
		brojTelefonaLabel.setBackground(telefon1.getBoja());
		brojTelefonaLabel.setFont(new Font("Arial", Font.BOLD, 20));
		
		brojTelefonaPanel1.add(brojTelefonaLabel);
		this.add(telefon1);
		this.add(telefon2);
		
		//this.add(bgColorMenu);
		this.revalidate();
		//this.add(brojTelefonaPanel,BorderLayout.SOUTH);
		//this.add(telefon1,BorderLayout.CENTER);
	}
	public App()
	{
		setBounds(700,200,384,700);
		setResizable(true);
		setTitle("GluviTelefoni");
		
		
		
		 
		
		dodajKomponente();
		
		//showHelpDialog();
		
		
		
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				dispose();
			}
			
		});
		addComponentListener(new ComponentAdapter() {
			
			@Override
			public void componentResized(ComponentEvent e) {
				//metoda za menjanje
				//repaint
				//pack
			}
		
		});
		setVisible(true);
	}
	private void showHelpDialog() {
		Dialog help = new Dialog(this, ModalityType.APPLICATION_MODAL);
		help.setTitle("Help");
		help.add(new Label("Use a-s-w-d to move.", Label.CENTER));
		help.setBounds(700, 200, 100, 100);
		help.setResizable(false);
		
		help.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				help.dispose();
			}
		});;
		
		help.setVisible(true);
	}
	public static void main(String[] args) {
		new App();

	}

}
