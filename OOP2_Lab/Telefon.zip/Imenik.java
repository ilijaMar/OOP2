package Imenik;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Frame;
import java.awt.GridLayout;

//import komponente.LoginForm;

public class Imenik extends ListaStavki {
	
	
	private int i=0;
	public Imenik()
	{
		this.setLayout(new GridLayout(0,1,0,-5));
	}
	public String getImeKorisnika(BrojTelefona broj) throws GNePostoji
	{
		for(Stavka s : stavke)
		{
			Kontakt k=(Kontakt) s;
			if(k.getTelefon().uporediBroj(broj))
			{
				return k.getIme();
			}
		}
		throw new GNePostoji();
		
	}
	public BrojTelefona getBrojKorisnika(String ime) throws GNePostoji
	{
		for(Stavka s : stavke)
		{
			Kontakt k=(Kontakt) s;
			if(k.getIme().equals(ime))
			{
				return k.getTelefon();
			}
		}
		throw new GNePostoji();
		
	}
	public void dodajKontakt(Stavka s)
	{
		if(s instanceof Kontakt)
		{
			stavke.add(s);
		}
		this.add(s,i++);
		this.revalidate();
	}
	public void ispisImenika()
	{
		for(Stavka s : stavke)
		{
			Kontakt k=(Kontakt) s;
			System.out.println(k.getIme()+": "+k.getTelefon()+"\n");
		}
	}
	
	public static void main(String[] args) throws InterruptedException 
	{
		
		Frame frame = new Frame();
        frame.setLayout(new BorderLayout());
        frame.setBounds(700, 200, 400, 400);
        frame.setVisible(true);
        Imenik imenik=new Imenik();
        //ListaStavki lista = new ListaStavki();
        frame.add(imenik, BorderLayout.NORTH);
        imenik.dodajKontakt(new Stavka("Naslov1", "Tekst1"));
        Thread.sleep(500);
        imenik.dodajKontakt(new Stavka("Naslov2", "Tekst2"));
        Thread.sleep(500);
        imenik.dodajKontakt(new Stavka("Naslov3", "Tekst3"));

	}
	

}
