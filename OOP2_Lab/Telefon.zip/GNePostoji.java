package Imenik;

public class GNePostoji extends Exception {

}
