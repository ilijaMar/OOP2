package Imenik;

public class Kontakt extends Stavka {
	
	
	private String ime;
	private BrojTelefona telefon;
	
	public Kontakt(String i,BrojTelefona t)
	{
		super(i, t.toString());
		ime=i;
		telefon=t;
		
	}
	public String getIme() {
		return ime;
	}
	public BrojTelefona getTelefon() {
		return telefon;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
