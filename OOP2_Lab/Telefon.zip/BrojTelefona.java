package Imenik;

import java.awt.desktop.AboutHandler;

public class BrojTelefona {

	private int kodDrzave;
	private int pozivniBroj;
	private int broj;
	
	public BrojTelefona(String brojString)
	{
		kodDrzave=Integer.parseInt(brojString.substring(1, 4));
		pozivniBroj=Integer.parseInt(brojString.substring(4, 6));
		broj=Integer.parseInt(brojString.substring(6));
	}
	
	
	
	
	public BrojTelefona(int kodDrzave, int pozivniBroj, int broj) 
	{
		
		this.kodDrzave = kodDrzave;
		this.pozivniBroj = pozivniBroj;
		this.broj = broj;
	}
	public boolean uporediDrzavu(BrojTelefona b)
	{
		return kodDrzave==b.kodDrzave;
	}
	public boolean uporediMrezu(BrojTelefona b)
	{
		return (kodDrzave==b.kodDrzave && pozivniBroj==b.pozivniBroj);
	}
	public boolean uporediBroj(BrojTelefona b)
	{
		return broj==b.broj;
	}
	
	@Override
	public String toString() {
		
		return "+"+kodDrzave+" "+pozivniBroj+" "+broj;
	}



	public static void main(String[] args) {
	
		BrojTelefona brojTelefona=new BrojTelefona("+381607030350");
		System.out.println(brojTelefona.toString());
	}

}
