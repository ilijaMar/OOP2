package Imenik;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTable.PrintMode;

public class Tastatura extends Panel implements Runnable {

	private int x=3;
	private int y=4;
	private Button jedanButton=new Button("1");
	private Button dvaButton=new Button("2");
	private Button triButton=new Button("3");
	private Button cetiriButton=new Button("4");
	private Button petButton=new Button("5");
	private Button sestButton=new Button("6");
	private Button sedamButton=new Button("7");
	private Button osamButton=new Button("8");
	private Button devetButton=new Button("9");
	private Button zvezdicaButton=new Button("*");
	private Button nulaButton=new Button("0");
	private Button plusButton=new Button("+");
	private Label natpis=new Label("");
	private Label natpisi=new Label("");
	private int flag;
	private String trenString;
	private int trenIndex;
	private Thread nit;
	private int brojKlikova=0;
	public Label getNatpis() {
		return natpis;
	}
	public Label getNatpisi() {
		return natpisi;
	}
	public void setFlag(int f) {
		this.flag = f;
	}
	private void slova(Button kliknuo,int m)
	{
		if(nit==null && flag==1) 
		{
			trenString=kliknuo.getLabel();
			trenIndex=0;
			natpisi.setText(natpisi.getText().concat(""+trenString.charAt(trenIndex)));
			nit=new Thread(Tastatura.this);
			nit.start();
			
		}
		else if(flag==1 && nit!=null)
		{
			
			nit.interrupt();
			nit=null;
			
			if(kliknuo.getLabel().equals(trenString))
			{
				trenIndex++;
				trenIndex%=m;
				
				natpisi.setText(natpisi.getText().substring(0, natpisi.getText().length()-1)+trenString.charAt(trenIndex));
				nit=new Thread(Tastatura.this);
				nit.start();

			}
			else 
			{
				
				if(flag==0)
					natpis.setText(natpis.getText().concat("1"));
				
				
				trenIndex=0;
				
				trenString=kliknuo.getLabel();
				natpisi.setText(natpisi.getText().concat(""+trenString.charAt(trenIndex)));

				nit=new Thread(Tastatura.this);
				nit.start();
			}
		}
	}
	/*
	public synchronized void zavrsiPrethodnoIscravanje()
	{
		if(nitZaCrtanje!=null)
		{
			nitZaCrtanje.interrupt();
		}
		while(nitZaCrtanje!=null) 
		{
			try {
				wait();
			} catch (InterruptedException e) {}
		}
	}
	
	public synchronized void dodaj(int element) throws InterruptedException//2 razlicite niti ne mogu dodavati i uzimati u nekom trenutku
	{
		while(kapacitet==brojElemenata) //!!! Ako nam je cela metoda synchronized znaci da drzimo kljuc OBJEKTA za koje je pozvan metod dodaj
		{
				//ako nam je bafer pun
				this.wait();//TEKUCI objekat se blokira zato sto drzimo njegovu bravu
		} 
		niz[kraj]=element; //dodavanje elementa i azuriranje pokazivaca
		kraj++;
		if(kraj==kapacitet) kraj=0; 
		brojElemenata++;
		
		this.notifyAll();//obacesavamo sve da u baderu ima >0 elemenata
	}
	
	public synchronized int uzmi() throws InterruptedException
	{
		while(brojElemenata==0) this.wait();
		
		int elem=niz[pocetak];
		niz[pocetak]=0;
		pocetak=(pocetak+1)%kapacitet;
	    brojElemenata--;
	    
	    this.notifyAll();
		
		return elem;
	}
	*/
	public void dodajKomponente()
	{
		addKeyListener(new KeyAdapter() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				char dugme=e.getKeyChar();
				switch (dugme) {
				case KeyEvent.VK_W:
				{
					System.out.println("klknulo se W");
					break;
				}
					default:
					break;
				}
			}
		
		});
		CheckboxGroup polGrupa=new CheckboxGroup();
		
		Checkbox muskipol=new Checkbox("Muski",true,polGrupa);
		Checkbox zenskipol=new Checkbox("Zenski",false,polGrupa);
		//password.setEchoChar('*');
		//password.addTextListener((te)-> {
		
		jedanButton.setFont(new Font("Ariel", Font.BOLD, 20));
		dvaButton.setFont(new Font("Ariel", Font.BOLD, 20));
		triButton.setFont(new Font("Ariel", Font.BOLD, 20));
		cetiriButton.setFont(new Font("Ariel", Font.BOLD, 20));
		petButton.setFont(new Font("Ariel", Font.BOLD, 20));
		sestButton.setFont(new Font("Ariel", Font.BOLD, 20));
		sedamButton.setFont(new Font("Ariel", Font.BOLD, 20));
		osamButton.setFont(new Font("Ariel", Font.BOLD, 20));
		devetButton.setFont(new Font("Ariel", Font.BOLD, 20));
		nulaButton.setFont(new Font("Ariel", Font.BOLD, 20));
		zvezdicaButton.setFont(new Font("Ariel", Font.BOLD, 20));
		plusButton.setFont(new Font("Ariel", Font.BOLD, 20));
		
		
		jedanButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				
				Button kliknuo=(Button) e.getSource();
				int m=3;
				if(flag==0)
					natpis.setText(natpis.getText().concat("1"));
				else slova(kliknuo,m);
				
				
				
			}
		});
		dvaButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				Button kliknuo=(Button) e.getSource();
				int m=3;
				
				if(flag==0)
					natpis.setText(natpis.getText().concat("2"));
				else slova(kliknuo,m);
			}
		});
		triButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				Button kliknuo=(Button) e.getSource();
				int m=3;
				if(flag==0)
					natpis.setText(natpis.getText().concat("3"));
				else slova(kliknuo,m);
			}
		});
		cetiriButton.addMouseListener(new MouseAdapter() {
	
			@Override
			public void mouseClicked(MouseEvent e) {
				Button kliknuo=(Button) e.getSource();
				int m=3;
				if(flag==0)
					natpis.setText(natpis.getText().concat("4"));
				else slova(kliknuo,m);
			}
		});
		petButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				Button kliknuo=(Button) e.getSource();
				int m=3;
				if(flag==0)
					natpis.setText(natpis.getText().concat("5"));
				else slova(kliknuo,m);
			}
		});
		sestButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				Button kliknuo=(Button) e.getSource();
				int m=3;
				if(flag==0)
					natpis.setText(natpis.getText().concat("6"));
				else slova(kliknuo,m);
			}
		});
		sedamButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				Button kliknuo=(Button) e.getSource();
				int m=4;
				if(flag==0)
					natpis.setText(natpis.getText().concat("7"));
				else slova(kliknuo,m);
			}
		});
		osamButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				Button kliknuo=(Button) e.getSource();
				int m=3;
				if(flag==0)
					natpis.setText(natpis.getText().concat("8"));
				else slova(kliknuo,m);
			}
		});
		devetButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				Button kliknuo=(Button) e.getSource();
				int m=4;
				if(flag==0)
					natpis.setText(natpis.getText().concat("9"));
				else slova(kliknuo,m);
			}
		});
		nulaButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				Button kliknuo=(Button) e.getSource();
				int m=3;
				if(flag==0)
					natpis.setText(natpis.getText().concat("0"));
				else slova(kliknuo,m);
			}
		});
		zvezdicaButton.addMouseListener(new MouseAdapter() {
					
			@Override
			public void mouseClicked(MouseEvent e) {
				Button kliknuo=(Button) e.getSource();
				int m=3;
				if(flag==0)
					natpis.setText(natpis.getText().concat("*"));
				else slova(kliknuo,m);
			}
		});
		plusButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				Button kliknuo=(Button) e.getSource();
				int m=3;
				if(flag==0)
					natpis.setText(natpis.getText().concat("+"));
				else slova(kliknuo,m);
			}
		});
		
		
		
		this.setPreferredSize(new Dimension(10,228));
		this.setLayout(new GridLayout(4,3));
		
		this.add(jedanButton);
		this.add(dvaButton);
		this.add(triButton);
		this.add(cetiriButton);
		this.add(petButton);
		this.add(sestButton);
		this.add(sedamButton);
		this.add(osamButton);
		this.add(devetButton);
		this.add(zvezdicaButton);
		this.add(nulaButton);
		this.add(plusButton);
		//jedanButton.setPreferredSize(new Dimension(57,10));
		
		
	}
	
	public Button getJedanButton() {
		return jedanButton;
	}
	public Button getDvaButton() {
		return dvaButton;
	}
	public Button getTriButton() {
		return triButton;
	}
	public Button getCetiriButton() {
		return cetiriButton;
	}
	public Button getPetButton() {
		return petButton;
	}
	public Button getSestButton() {
		return sestButton;
	}
	public Button getSedamButton() {
		return sedamButton;
	}
	public Button getOsamButton() {
		return osamButton;
	}
	public Button getDevetButton() {
		return devetButton;
	}
	public Button getZvezdicaButton() {
		return zvezdicaButton;
	}
	public Button getNulaButton() {
		return nulaButton;
	}
	public Button getPlusButton() {
		return plusButton;
	}
	public Tastatura()
	{
		dodajKomponente();
	}
	@Override
	public void run() {
	
		try {
			nit.sleep(1000);
			//natpisi.setText(natpisi.getText().concat(""+trenString.charAt(trenIndex)));
			//trenIndex=0;
		} catch (InterruptedException e) {
			return;
			
		}
		nit=null;
		trenIndex=0;
	}
}
