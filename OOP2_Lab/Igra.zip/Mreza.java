package Igra;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Panel;
import java.awt.Dialog.ModalityType;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.HashSet;

public class Mreza extends Panel{
	
	
	
	private int x=4;
	private int y=5;
	private ArrayList<Polje> izabranaPolja=new ArrayList<>();
	private HashSet<Integer> izabraneVrednosti=new HashSet<>();
	private Igra igraVlasnik;
	
	private void dodajKomponente()
	{
		CheckboxGroup polGrupa=new CheckboxGroup();
		
		Checkbox muskipol=new Checkbox("Muski",true,polGrupa);
		Checkbox zenskipol=new Checkbox("Zenski",false,polGrupa);
		this.setLayout(new GridLayout(x,y,3,3));
		this.setBackground(Color.BLACK);
		for (int i = 0; i < x; i++) 
		{
			for(int j = 0; j < y; j++)
			{
				Polje polje=new Polje(this, i*y+j, "SLOBODNO");
				polje.addMouseListener(new MouseAdapter() {
					
					
					@Override
					public void mouseClicked(MouseEvent e) {
						Polje polje=(Polje) e.getSource();
						
						
						if(polje.getStatus().equals("SLOBODNO"))
						{
							
							polje.setStatus("IZABRANO");
							izabranaPolja.add(polje);
							izabraneVrednosti.add(polje.getBrojPolja());
						}
						else if(polje.getStatus().equals("IZABRANO"))
						{
							polje.setStatus("SLOBODNO");
							izabranaPolja.remove(polje);
							izabraneVrednosti.remove(polje.getBrojPolja());
						}
						polje.repaint();
						double iznost=((double)(x*y)/izabranaPolja.size());
						if(izabranaPolja.isEmpty()) iznost=0;
						String kvota = String.format("%.2f", iznost);
						if(izabranaPolja.isEmpty()) kvota="1";
						System.out.println("iznos:"+iznost);
						igraVlasnik.getKvotaIznos().setText(kvota);
						//polje.nacrtajElipsu();
						//System.out.println(polje.getBrojPolja()+" status:"+polje.getStatus());
					}
					
				});
				this.add(polje);
			
			}
		}
	}
	public int getX() {
		return x;
	}
	public int getY() {
		return y;
	}
	public ArrayList<Polje> getIzabranaPolja() 
	{
		return izabranaPolja;
	}
	public HashSet<Integer> getIzabraneVrednosti() {
		return izabraneVrednosti;
	}
	public Mreza(Igra i)
	{
		this.x=x;
		this.y=y;
		dodajKomponente();
		addKeyListener(new KeyAdapter() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				char dugme=e.getKeyChar();
				switch (dugme) {
				case KeyEvent.VK_W:
				{
					System.out.println("klknulo se W");
					break;
				}
					default:
					break;
				}
			}
		
		});
	}
	public Mreza(int x,int y,Igra i) 
	{
		
		this.x=x;
		this.y=y;
		this.igraVlasnik=i;
		dodajKomponente();
	}

}
