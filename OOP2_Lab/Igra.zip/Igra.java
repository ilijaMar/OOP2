package Igra;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.Dialog.ModalityType;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Igra extends Frame {
	
	 private class PotvrdiGasenje extends Dialog
		{
			private Button okButton=new Button("Ok");
			private Button cancelButton=new Button("Cancel");
			
			public void paint(Graphics g)
			{
				Graphics graphics=getGraphics();
				g.drawString("morate izabrati jedno dugme", 20, 70);
				super.paint(g);
			}
			public PotvrdiGasenje(Frame owner) {
				super(owner);
				setTitle("Potvrditi");
				setBounds(owner.getX()+owner.getWidth()/2,owner.getY()+owner.getHeight()/2,200,150);
				setResizable(false);
				setModalityType(ModalityType.APPLICATION_MODAL);//ne moze nista drugo da se klikne izvan dijaloga
				
				Panel dugmiciPanel=new Panel();
				
				okButton.addActionListener((ae)->{
					//Telefon.this.dispose();
				});
				cancelButton.addActionListener((ae)->{
					//PotvrdiGasenje.this.dispose();
				});
				dugmiciPanel.add(okButton);
				dugmiciPanel.add(cancelButton);
				
				add(dugmiciPanel,BorderLayout.SOUTH);
				addWindowListener(new WindowAdapter() {
					
					@Override
					public void windowClosing(WindowEvent e) {
						dispose();
					}
				});
				setVisible(true);
				
			}
			
		}
	private Mreza mreza=new Mreza(4,5,this);
	private Panel statusBar=new Panel(new FlowLayout(FlowLayout.CENTER));
	private Panel panelZaUpravljanje=new Panel(new GridLayout(0, 1));
	private Label radnomBrojLabela=new Label("");
	
	private Label balansLabel=new Label("Balans:");
	private Label balansiznostLabel=new Label("0");
	
	private Label ulogLabel=new Label("Ulog:");
	
	private Label kvotaLabel=new Label("Kvota:");
	private Label kvotaIznos=new Label("1");
	
	private Label dobitakLabel=new Label("Dobitak:");
	private Label dobitakIznost=new Label("0");
	
	private TextField ulogIznost=new TextField(5);
	private Button igrajDugme=new Button("Igraj");
	Generator generator=new Generator();
	
	double BalansUkupan=0;
	public Mreza getMreza() {
		return mreza;
	}
	private void dodajKomponente()
	{
		Panel balans=new Panel(new FlowLayout(FlowLayout.LEFT));
		Panel ulog=new Panel(new FlowLayout(FlowLayout.LEFT));
		Panel kvota=new Panel(new FlowLayout(FlowLayout.LEFT));
		Panel dobitak=new Panel(new FlowLayout(FlowLayout.LEFT));
		Panel igraj=new Panel(new FlowLayout(FlowLayout.RIGHT));
		
		panelZaUpravljanje.setBackground(Color.LIGHT_GRAY);
		statusBar.setBackground(Color.DARK_GRAY);
		
		
		
		igrajDugme.addActionListener((ae)->{
			
			int generisaniBroj=generator.generisiBroj(0, mreza.getX()*mreza.getY());
			radnomBrojLabela.setText(""+generisaniBroj);
			radnomBrojLabela.revalidate();
			double ulogp=Double.parseDouble(ulogIznost.getText()); 
			double kvotap=Double.parseDouble(kvotaIznos.getText());
			if(mreza.getIzabraneVrednosti().isEmpty())
			{
				System.out.println("Morate izabrati jedno polje");
				new PotvrdiGasenje(this);
			}
			else {
			if(mreza.getIzabraneVrednosti().contains(generisaniBroj))
			{
				statusBar.setBackground(Color.GREEN);
				
				BalansUkupan+=kvotap*ulogp;
				dobitakIznost.setText(""+kvotap*ulogp);
				
			}
			else {
				
				statusBar.setBackground(Color.RED);
				BalansUkupan-=ulogp;
				dobitakIznost.setText("-"+ulogp);
			}
			balansiznostLabel.setText(""+BalansUkupan);
			dobitakIznost.revalidate();
			}
		});
		
		
		statusBar.add(radnomBrojLabela);
		
		panelZaUpravljanje.setPreferredSize(new Dimension(150,10));
		panelZaUpravljanje.add(balans);
		panelZaUpravljanje.add(ulog);
		panelZaUpravljanje.add(kvota);
		panelZaUpravljanje.add(dobitak);
		panelZaUpravljanje.add(igraj);
		
		
		balans.add(balansLabel);
		balans.add(balansiznostLabel);
		
		ulog.add(ulogLabel);
		ulog.add(ulogIznost);
		ulogIznost.setText("100");
		
		kvota.add(kvotaLabel);
		kvota.add(kvotaIznos);
		//kvotaIznos.setText(""+mreza.getX()*mreza.getY()/mreza.getIzabranaPolja().size());
		
		dobitak.add(dobitakLabel);
		dobitak.add(dobitakIznost);
		igraj.add(igrajDugme);
		
		this.add(statusBar,BorderLayout.SOUTH);
		this.add(panelZaUpravljanje,BorderLayout.EAST);
		this.add(mreza,BorderLayout.CENTER);
	}
	
	public Label getKvotaIznos() {
		return kvotaIznos;
	}
	public Igra()
	{
		
		
		setBounds(700,200,500,400);
		setResizable(true);
		setTitle("Igra");
		
		
		
		 
		
		dodajKomponente();
		//showHelpDialog();
		
		
		
		
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				dispose();
			}
			
		});
		addComponentListener(new ComponentAdapter() {
			
			@Override
			public void componentResized(ComponentEvent e) {
				//metoda za menjanje
				//repaint
				//pack
			}
		
		});
		
		setVisible(true);
		
		
	}
	
	
	private void showHelpDialog() {
		Dialog help = new Dialog(this, ModalityType.APPLICATION_MODAL);
		help.setTitle("Help");
		help.add(new Label("Use a-s-w-d to move.", Label.CENTER));
		help.setBounds(700, 200, 100, 100);
		help.setResizable(false);
		
		help.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				help.dispose();
			}
		});;
		
		help.setVisible(true);
	}

	public static void main(String[] args) {
		
		new Igra();
	}

}
