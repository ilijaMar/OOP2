package Igra;



import java.awt.Label;

public class Timer extends Thread {
	
	private Label label;
	private int s, m;
	private boolean da_li_nit_radi;

	public Timer(Label label) {
		this.label = label;
	}
	
	public void run() {
		try {
			while(!isInterrupted()) {
				
				synchronized (this) { //cekamo dokle pokreni_nitd nas neko ne probudi
					while(!da_li_nit_radi){
						wait();
					}
				}
				
				label.setText(toString());
				label.revalidate();
				sleep(1000);//na jednu sekundu azuriramo
				s++;
				if (s % 60 == 0) { m++; s = 0; }
			}
		} catch(InterruptedException e) {}
	}
	
	public synchronized void pokreni_nit() {
		da_li_nit_radi = true;
		notify();
	}
	
	public synchronized void pauziraj_nit() {
		da_li_nit_radi = false;
	}
	
	public synchronized void resetuj_timer() {
		m = s = 0;
	}
	
	@Override
	public String toString() {
		return String.format("%02d:%02d", m, s);
	}
	//mesto na kome se poziva timer ce imati:Timer t
	//
	//on se kreira kad se zapocinje:if(timer!=null)-ukokliko smo vec igrali timer.interupt() timer=new TImer
	//timer.start(), timer.pokreninit()
	
	//tamo gde se pauzira/gasi timer.interupt
}

