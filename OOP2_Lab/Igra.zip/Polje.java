package Igra;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Label;

public class Polje extends Canvas {
	
	private Mreza mrezaVlasnik;
	private int brojPolja;
	private String status="SLOBODNO";
	
	int flag=0;
	public void drawCenteredString(Graphics g, String text,Color boja) 
	{
		
		
	  
	    
	    g.setFont(new Font("Verdana", Font.BOLD,Math.min(this.getWidth(),this.getHeight())/3));
	    FontMetrics metrics = g.getFontMetrics(g.getFont());
	    int x = 0 + (this.getWidth() - metrics.stringWidth(text)) / 2;
	    
	    int y = 0 + ((this.getHeight() - metrics.getHeight()) / 2) + metrics.getAscent();
	   
	    g.setColor(boja);
	    g.drawString(text, x, y);
	}
	/*
	public synchronized void zavrsiPrethodnoIscravanje()
	{
		if(nitZaCrtanje!=null)
		{
			nitZaCrtanje.interrupt();
		}
		while(nitZaCrtanje!=null) 
		{
			try {
				wait();
			} catch (InterruptedException e) {}
		}
	}
	
	public synchronized void dodaj(int element) throws InterruptedException//2 razlicite niti ne mogu dodavati i uzimati u nekom trenutku
	{
		while(kapacitet==brojElemenata) //!!! Ako nam je cela metoda synchronized znaci da drzimo kljuc OBJEKTA za koje je pozvan metod dodaj
		{
				//ako nam je bafer pun
				this.wait();//TEKUCI objekat se blokira zato sto drzimo njegovu bravu
		} 
		niz[kraj]=element; //dodavanje elementa i azuriranje pokazivaca
		kraj++;
		if(kraj==kapacitet) kraj=0; 
		brojElemenata++;
		
		this.notifyAll();//obacesavamo sve da u baderu ima >0 elemenata
	}
	
	public synchronized int uzmi() throws InterruptedException
	{
		while(brojElemenata==0) this.wait();
		
		int elem=niz[pocetak];
		niz[pocetak]=0;
		pocetak=(pocetak+1)%kapacitet;
	    brojElemenata--;
	    
	    this.notifyAll();
		
		return elem;
	}
	*/
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStatus() {
		return status;
	}
	public void setFlag(int flag) 
	{
		this.flag = flag;
	}
	public int getBrojPolja() 
	{
		return brojPolja;
	}
	@Override
	public void paint(Graphics g) {
		
		String nat=""+brojPolja;
		drawCenteredString(g, nat,Color.BLACK);
		if(status.equals("IZABRANO"))
		{
			nacrtajElipsu();
			drawCenteredString(g, nat,Color.WHITE);
		}
		
		
	}
	public void nacrtajElipsu()
	{
		String nat=""+brojPolja;
		Graphics g=getGraphics();
		g.setColor(Color.BLUE);
		g.fillOval(0, 0, this.getWidth(), this.getHeight());
		this.revalidate();
		//drawCenteredString(g, nat);
	}
	public Polje(Mreza mrezaVlasnik, int brojPolja, String status) 
	{
	
		this.mrezaVlasnik = mrezaVlasnik;
		this.brojPolja = brojPolja;
		this.status = status;
		
		
		this.setSize(new Dimension(75,75));
		this.setBackground(Color.ORANGE);
		
		
		
		Graphics g=getGraphics();
		repaint();
		//drawCenteredString(this.getGraphics(), nat);
			
	}
	
	

}
