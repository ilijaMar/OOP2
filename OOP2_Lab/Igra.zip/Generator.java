package Igra;

import java.util.Random;

public class Generator {

	
	
	
	
	
	
	
	
	
	public int generisiBroj(int donjaGranica,int gornjaGranica)
	{
		Random random=new Random();
		return random.nextInt(gornjaGranica - donjaGranica + 1) + donjaGranica;
	}





	public static void main(String[] args) {
	
		Generator r=new Generator();
		System.out.println(r.generisiBroj(50, 60));
	}

}
