package ProdajaSladoleda;

import java.awt.Color;

//import komponente.LoginForm;

public class Ukus {
	
	
	private String naziv;
	private Color boja;
	
	public Ukus(String naziv, Color boja) {
		
		this.naziv = naziv;
		this.boja = boja;
	}

	public String getNaziv() {
		return naziv;
	}

	public Color getBoja() {
		return boja;
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if(obj==this) return true;
		
		if (!(obj instanceof Ukus)) {
            return false;
        }
		
		Ukus u=(Ukus)obj;
		
		if(u.naziv.equals(this.naziv)) return true;
		
		
		
		
		
		
		return false;
	}

	@Override
	public String toString() {
		return "[" + naziv + "]";
	}
	
	
	public static void main(String[] args) 
	{
		Ukus u1=new Ukus("Cokolada", Color.BLACK);
		Ukus u2=new Ukus("Cokolada", Color.BLACK);
		Ukus u3=new Ukus("Vanila", Color.WHITE);
		
		if(u1.equals(u2)) System.out.println("Ukusi su jednaki");
		else System.out.println("Ukusi nisu jednaki");
		
		
		if(u1.equals(u3)) System.out.println("Ukusi su jednaki");
		else System.out.println("Ukusi nisu jednaki");
		
		System.out.println(u1.toString());
		System.out.println(u2.toString());
		System.out.println(u3.toString());
		
		
		
		
		

	}
	
	
	
	

}
