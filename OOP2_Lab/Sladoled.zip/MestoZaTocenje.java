package ProdajaSladoleda;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Panel;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.ArrayList;



public class MestoZaTocenje extends Canvas implements Runnable {
	
	
	
	
	private Sladoled sladoled;
	
	private Thread nitZaCrtanje;
	private AparatZaTocenje aparatZaTocenje;
	private Ukus trenutniUkus;
	private int pomeraj;//=this.getHeight()/10;
	private int pocetnoY;//=this.getHeight()-pomeraj;
	private int flag=0;
	class Pravougaonik
	{
		int x,y,sirina,visina;
		Color bojap;
	}
	private ArrayList<Pravougaonik> pravougaonici=new ArrayList<>();//lista cuva sve do sad nacrtane linije koje se crtaju svaki put ponovo kako bi uvek bile vidljive
	
	
	public MestoZaTocenje(AparatZaTocenje aparatOwner)
	{
		aparatZaTocenje=aparatOwner;
		addKeyListener(new KeyAdapter() {
			
			@Override
			public void keyTyped(KeyEvent e) {
				char dugme=e.getKeyChar();
				switch (dugme) {
				case KeyEvent.VK_W:
				{
					System.out.println("klknulo se W");
					break;
				}
					default:
					break;
				}
			}
		
		});
		
	}
	public void setSladoled(Sladoled s)
	{
		sladoled=s;
	}
	public void setUkus(Ukus u)
	{
		trenutniUkus=u;
	}
	/*
	public synchronized void zavrsiPrethodnoIscravanje()
	{
		if(nitZaCrtanje!=null)
		{
			nitZaCrtanje.interrupt();
		}
		while(nitZaCrtanje!=null) 
		{
			try {
				wait();
			} catch (InterruptedException e) {}
		}
	}
	
	public synchronized void dodaj(int element) throws InterruptedException//2 razlicite niti ne mogu dodavati i uzimati u nekom trenutku
	{
		while(kapacitet==brojElemenata) //!!! Ako nam je cela metoda synchronized znaci da drzimo kljuc OBJEKTA za koje je pozvan metod dodaj
		{
				//ako nam je bafer pun
				this.wait();//TEKUCI objekat se blokira zato sto drzimo njegovu bravu
		} 
		niz[kraj]=element; //dodavanje elementa i azuriranje pokazivaca
		kraj++;
		if(kraj==kapacitet) kraj=0; 
		brojElemenata++;
		
		this.notifyAll();//obacesavamo sve da u baderu ima >0 elemenata
	}
	
	public synchronized int uzmi() throws InterruptedException
	{
		while(brojElemenata==0) this.wait();
		
		int elem=niz[pocetak];
		niz[pocetak]=0;
		pocetak=(pocetak+1)%kapacitet;
	    brojElemenata--;
	    
	    this.notifyAll();
		
		return elem;
	}
	*/
	public void setPocetnoY()
	{
		
		pomeraj=this.getHeight()/10;
		pocetnoY=this.getHeight()-pomeraj;
		System.out.println("pom: "+pomeraj);
		System.out.println("pocy: "+pocetnoY);
	}
	public Sladoled getSladoled()
	{
		return sladoled;
	}
	public void prekini()
	{
		nitZaCrtanje.interrupt();
	}
	
	public void pokreniNit() 
	{
		nitZaCrtanje=new Thread(this);
		nitZaCrtanje.start();
	}
	public void obrisiKanvas()
	{
		Graphics g=getGraphics();
		g.clearRect(0, 0, this.getWidth(),this.getHeight() );
	}
	public synchronized void zavrsiPrethodnoIscravanje()
	{
		if(nitZaCrtanje!=null)
		{
			nitZaCrtanje.interrupt();
		}
		while(nitZaCrtanje!=null) 
		{
			try {
				wait();
			} catch (InterruptedException e) {}
		}
	}
	public void dodajPravougaonik(Color boja) 
	{
		
		Pravougaonik p=new Pravougaonik();
		if(pomeraj==0)
		{
			pomeraj=this.getHeight()/10;
			pocetnoY=this.getHeight()-pomeraj;
		}
		p.x=0;
		p.y=pocetnoY;
		pocetnoY-=pomeraj;
		
		p.sirina=this.getWidth();
		p.visina=pomeraj;
		
		p.bojap=boja;
		Graphics g=getGraphics();
		//if(flag==1) g.setColor(Color.WHITE);
		//else
		g.setColor(boja);
		g.fillRect(p.x, p.y, p.sirina, p.visina);
		sladoled.dodajKuglu(trenutniUkus, 20);
		aparatZaTocenje.setLabelakugle(sladoled.toString());
		aparatZaTocenje.getLabelakugle().revalidate();
		if(sladoled.getVelicinaCase()==sladoled.trenutnoSladoleda())
		{
			System.out.println("Casa je puna");
			aparatZaTocenje.getProdaj().setEnabled(true);
			
			//aparatZaTocenje.setLabelakugle("");
			//sladoled.setVelicinaCase(0);
			
			flag=1;
			
		}
		aparatZaTocenje.getProdaj().revalidate();

	}
	public void resetujY()
	{
		pocetnoY=this.getHeight()-pomeraj;
	}
	@Override
	public void run() {
		Graphics g=this.getGraphics();
		
		
		
		try {
			
			while(!Thread.interrupted())
			{
				dodajPravougaonik(trenutniUkus.getBoja());
				Thread.sleep(500);
			}
			
		} catch (Exception e) {
			
		}
		synchronized (this) {
			nitZaCrtanje=null;
			notify();
		}
		
	}

}
