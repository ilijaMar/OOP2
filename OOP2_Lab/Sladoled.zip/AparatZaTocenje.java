package ProdajaSladoleda;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.Dialog.ModalityType;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;



public class AparatZaTocenje extends Panel {
	
	/*
	private class PotvrdiGasenje extends Dialog
	{
		private Button okButton=new Button("Ok");
		private Button cancelButton=new Button("Cancel");
		
		public void paint(Graphics g)
		{
			g.drawString("Poziv od: "+brojTelefona, 20, 70);
			super.paint(g);
		}
		public PotvrdiGasenje(Frame owner) {
			super(owner);
			setTitle("Potvrditi");
			setBounds(owner.getX()+owner.getWidth()/2,owner.getY()+owner.getHeight()/2,200,150);
			setResizable(false);
			setModalityType(ModalityType.APPLICATION_MODAL);//ne moze nista drugo da se klikne izvan dijaloga
			
			Panel dugmiciPanel=new Panel();
			
			okButton.addActionListener((ae)->{
				//Telefon.this.dispose();
			});
			cancelButton.addActionListener((ae)->{
				//PotvrdiGasenje.this.dispose();
			});
			dugmiciPanel.add(okButton);
			dugmiciPanel.add(cancelButton);
			
			add(dugmiciPanel,BorderLayout.SOUTH);
			addWindowListener(new WindowAdapter() {
				
				@Override
				public void windowClosing(WindowEvent e) {
					dispose();
				}
			});
			setVisible(true);
			
		}
		
	}
	*/
	private Button prodaj=new Button("Prodaj");
	Panel kutijeSladoleda=new Panel(new GridLayout(2,0));
	Panel panelZaTekstSladoleda=new Panel(new FlowLayout(FlowLayout.LEFT));
	Label labelakugle=new Label("");
	private int flag=0;
	Sladoled sladoled=new Sladoled(200);
	
	private MestoZaTocenje mestoZaTocenje=new MestoZaTocenje(this);
	
	private void dodajKomponente()
	{
		CheckboxGroup polGrupa=new CheckboxGroup();
		
		Checkbox muskipol=new Checkbox("Muski",true,polGrupa);
		Checkbox zenskipol=new Checkbox("Zenski",false,polGrupa);
		
		mestoZaTocenje.setSladoled(sladoled);
		prodaj.setEnabled(false);
		this.setLayout(new BorderLayout());
		
	
		
		Panel desniDeoPanel=new Panel(new GridLayout(2,1));
		
		
		Label labelaSladoled=new Label("Sladoled: ");
		
		labelaSladoled.setFont(new Font("Verdana", Font.BOLD,15));
		panelZaTekstSladoleda.setBackground(Color.GRAY);
		
		panelZaTekstSladoleda.add(labelaSladoled);
		panelZaTekstSladoleda.add(labelakugle);
		desniDeoPanel.add(prodaj);
		desniDeoPanel.add(mestoZaTocenje);
		desniDeoPanel.setPreferredSize(new Dimension(150,10));
		
		kutijeSladoleda.setBackground(Color.LIGHT_GRAY);
		
		prodaj.addActionListener((ae)->{
			
			mestoZaTocenje.obrisiKanvas();
			labelakugle.setText("");
			mestoZaTocenje.getSladoled().ocisti();
			mestoZaTocenje.resetujY();
			
		});
		
		
		
		
		
		this.add(panelZaTekstSladoleda,new BorderLayout().SOUTH);
		this.add(desniDeoPanel,new BorderLayout().EAST);
		this.add(kutijeSladoleda,new BorderLayout().CENTER);
		
		
		//jacinaSifre.revalidate();
		
		
		
		
		
		
		
	}
	public void postaviKoordinate()
	{
		mestoZaTocenje.setPocetnoY();
	}
	public Sladoled getSladoled() {
		return sladoled;
	}

	private int flagZaGrid=0;
	private int iGrid=2;
	private int jGrid=1;
	private void menjajGrid()
	{
		System.out.println("iGrid:"+iGrid+" jGrid:"+jGrid);
		if(flagZaGrid==0)
		{
			jGrid++;
			
		}
		else iGrid++;
		kutijeSladoleda.setLayout(new GridLayout(iGrid,jGrid));
		if(flagZaGrid==0) flagZaGrid=1;
		else flagZaGrid=0;
	}
	public void dodajUkus(String text,String boja)
	{
		
		Ukus ukus=new Ukus(text, Color.decode("#" + boja));
		
		
		Button ukusButton=new Button(text);
		ukusButton.setBackground(Color.decode("#" + boja));
		
		int postoji=0;
		if(flag==0)
		{
			
			kutijeSladoleda.add(ukusButton);
			//menjajGrid();
			
			
			
			mestoZaTocenje.getSladoled().dodajKuglu(ukus, 0);
			this.revalidate();
			flag=1;
		}
		else {
			
			for(Pair<Ukus, Integer> p:mestoZaTocenje.getSladoled().getUkusi())
			{
				//System.out.println(p.getKey().getNaziv()+"\t"+ukus.getNaziv());
				if(p.getKey().equals(ukus))
				{
					postoji=1;
					System.out.println("Ukus vec postoji");
				}
				
			}
		}
		if(postoji==0)
		{
			
			
			kutijeSladoleda.add(ukusButton);
			//menjajGrid();
			
			
			mestoZaTocenje.getSladoled().dodajKuglu(ukus, 0);
			this.revalidate();
		}
		ukusButton.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mousePressed(MouseEvent e) 
			{
				Button kliknuo=(Button) e.getSource();
				
				Color bojaPravougaonika=kliknuo.getBackground();
				
				mestoZaTocenje.pokreniNit();
				mestoZaTocenje.setUkus(ukus);
						
	
				//sladoled.dodajKuglu(ukus, 20);
				
				
				//labelakugle.setText(mestoZaTocenje.getSladoled().toString());
				//prodaj.revalidate();
				//labelakugle.revalidate();
				//System.out.println(kliknuo.getLabel());
				//System.out.println(sladoled.trenutnoSladoleda());
			}
			@Override
			public void mouseReleased(MouseEvent e) {
				//mestoZaTocenje.zavrsiPrethodnoIscravanje();
				
				mestoZaTocenje.prekini();
				mestoZaTocenje.zavrsiPrethodnoIscravanje();
				//labelakugle.setText(mestoZaTocenje.getSladoled().toString());
				//labelakugle.revalidate();
			}
			
		
		});
		
		
		
		
	}
	public void setLabelakugle(String t) {
		labelakugle.setText(t);
	}
	public Button getProdaj() {
		return prodaj;
	}
	public Label getLabelakugle() {
		return labelakugle;
	}
	public AparatZaTocenje()
	{
		dodajKomponente();
		
	}

}
