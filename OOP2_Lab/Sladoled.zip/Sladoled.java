package ProdajaSladoleda;

import java.awt.Color;
import java.awt.List;

import java.util.Map.Entry;
import java.util.ArrayList;

public class Sladoled {

	private ArrayList<Pair<Ukus,Integer>> ukusi=new ArrayList<Pair<Ukus,Integer>>();
	
	private int velicinaCase;
	
	
	public Sladoled(int velicinaCase) 
	{
		
		this.velicinaCase = velicinaCase;
	}
	
	public ArrayList<Pair<Ukus, Integer>> getUkusi() {
		return ukusi;
	}

	public int getVelicinaCase() {
		return velicinaCase;
	}
	
	public int trenutnoSladoleda()
	{
		int t=0;
		for(Pair<Ukus, Integer> p:ukusi)
		{
			t+=p.getValue();
		}
		return t;
	}
	public void dodajKuglu(Ukus u,int kolicina)
	{
		int flag=0;
		int trenutno=trenutnoSladoleda();
		
		for(Pair<Ukus, Integer> p:ukusi)
		{
			if(p.getKey().equals(u))//ako je ukus vec u listi
			{
				int trenKolicina=p.getValue();
				if(trenutno+kolicina<=velicinaCase)
					p.setValue(trenKolicina+kolicina);
				else p.setValue(trenKolicina+velicinaCase-trenutno);
				
				flag=1;
			}
				
		}
		if(flag==0)//ukus nije u casi
		{
			if(trenutno+kolicina<=velicinaCase)
				ukusi.add(new Pair<Ukus, Integer>(u, kolicina));
			else ukusi.add(new Pair<Ukus, Integer>(u, velicinaCase-trenutno));
		}
	
	}
	public void ocisti()
	{
		for(Pair<Ukus, Integer> p:ukusi)
		{
			p.setValue(0);
		}
	}
	public void setVelicinaCase(int velicinaCase) {
		this.velicinaCase = velicinaCase;
	}
	@Override
	public String toString() 
	{
		String s="";
		
		for(Pair<Ukus, Integer> p:ukusi)
		{
			s+=p.getValue()+"ml"+p.getKey().toString()+" ";
		}
		return s;
	}









	public static void main(String[] args) {
		Sladoled sladoled=new Sladoled(200);
		
		Ukus cokolada=new Ukus("Cokolada", Color.BLACK);
		Ukus vanila=new Ukus("Vanila", Color.WHITE);
		Ukus jagoda=new Ukus("Jagoda", Color.RED);
		
		sladoled.dodajKuglu(cokolada, 80);
		sladoled.dodajKuglu(vanila, 20);
		sladoled.dodajKuglu(cokolada, 80);
		//sladoled.dodajKuglu(cokolada, 80);
		//sladoled.dodajUkus(jagoda, 80);
		
		System.out.println(sladoled.toString());

	}

}
