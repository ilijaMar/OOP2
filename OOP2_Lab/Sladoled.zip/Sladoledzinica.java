package ProdajaSladoleda;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.Dialog.ModalityType;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

//import gui.DrawingLines.MouseEventHendler;

public class Sladoledzinica extends Frame {

	private TextField naziv=new TextField(10);
	private TextField boja=new TextField(10);
	private Button dodajUkus=new Button("Dodaj ukus");
	//private Button prodaj=new Button("Prodaj");
	
	private AparatZaTocenje aparatZaTocenje=new AparatZaTocenje();
	
	private void dodajKomponente()
	{
		
		Panel panelZaDodavanjeUkusaPanel=new Panel(new FlowLayout(FlowLayout.LEFT));
		
		//Panel pomocniPanel2=new Panel(new GridLayout(2, 1));
		//Panel kutijeSladoleda=new Panel(new GridLayout(2, 0));
		//Panel pomocniPanel=new Panel(new BorderLayout());
		//
		
		
		//kutijeSladoleda.setPreferredSize(new Dimension(200,10));
		//pomocniPanel2.setPreferredSize(new Dimension(200,10));
		//kutijeSladoleda.setBackground(Color.LIGHT_GRAY);
		//pomocniPanel2.setBackground(Color.WHITE);
		
		
		Label labelaNaziv=new Label("Naziv: ");
		Label labelaBoja=new Label("Boja: ");
		
		
		labelaNaziv.setFont(new Font("Verdana", Font.BOLD,15));
		labelaBoja.setFont(new Font("Verdana", Font.BOLD,15));
		
		
		panelZaDodavanjeUkusaPanel.add(labelaNaziv);
		panelZaDodavanjeUkusaPanel.add(naziv,BorderLayout.WEST);
		panelZaDodavanjeUkusaPanel.setBackground(Color.CYAN);
		panelZaDodavanjeUkusaPanel.add(labelaBoja);
		panelZaDodavanjeUkusaPanel.add(boja);
		panelZaDodavanjeUkusaPanel.add(dodajUkus);
		
		
		dodajUkus.addActionListener((ae)->{
			
			aparatZaTocenje.dodajUkus(naziv.getText(), boja.getText());
		});
		
		
		
		
		
		this.add(panelZaDodavanjeUkusaPanel,BorderLayout.SOUTH);
		this.add(aparatZaTocenje,BorderLayout.CENTER);
		
		//
	
	
		//
		
		
		//panelZaTekstSladoleda.add(new Label("l;skda;lk asdka sdl;k das;lkd asdk  sdasd asd asd asd asd as: "));
		
		//pomocniPanel.add(panelZaTekstSladoleda,BorderLayout.SOUTH);
		//pomocniPanel.add(pomocniPanel2,BorderLayout.EAST);
		//pomocniPanel.add(kutijeSladoleda,BorderLayout.CENTER);
		//prodaj.setSize(new Dimension());
		//prodaj.setSize(pomocniPanel2.getWidth(),pomocniPanel2.getHeight()/2);
		//pomocniPanel2.add(prodaj);
		//pomocniPanel2.setPreferredSize(new Dimension(150,10));
		
		
		
		
	}
	
	
	
	
	
	
	public Sladoledzinica()
	{
		
		
		setBounds(700,200,500,400);
		setResizable(false);
		setTitle("Sladoledzinica");
		
		
		
		 
		
		dodajKomponente();
		//showHelpDialog();
		aparatZaTocenje.postaviKoordinate();
		
		
		
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				dispose();
			}
			
		});
		addComponentListener(new ComponentAdapter() {
			
			@Override
			public void componentResized(ComponentEvent e) {
				//metoda za menjanje
				//repaint
				//pack
			}
		
		});
		
		setVisible(true);
	}
	
	
	
	
	
	
	private void showHelpDialog() {
		Dialog help = new Dialog(this, ModalityType.APPLICATION_MODAL);
		help.setTitle("Help");
		help.add(new Label("Use a-s-w-d to move.", Label.CENTER));
		help.setBounds(700, 200, 100, 100);
		help.setResizable(false);
		
		help.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				help.dispose();
			}
		});;
		
		help.setVisible(true);
	}
	
	public static void main(String[] args) {
		System.out.println("Cokolada: 664000");
		System.out.println("Vanila: FFFFDF");
		System.out.println("Jagoda: F9D0DD");
		
		new Sladoledzinica();

	}

}
